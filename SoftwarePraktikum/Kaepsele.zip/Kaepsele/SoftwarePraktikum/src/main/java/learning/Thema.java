package learning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * Die Klasse Thema stellt einen Beitrag auf der Pinnwand eines Freundes bzw.
 * einer Gruppe dar.
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "THEMA")
@PrimaryKeyJoinColumn(name="thema_id", referencedColumnName = "inhalt_id")
public class Thema extends Inhalt implements java.io.Serializable{

	@OneToMany(fetch = FetchType.EAGER, mappedBy="thema")
	@Cascade(CascadeType.SAVE_UPDATE)
	public Set<Kommentar> kommentare;
    
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="pinnwand_id")
	@Cascade(CascadeType.SAVE_UPDATE)
    public Pinnwand pinnwand;
	
	@Transient
	public ArrayList<Kommentar> hilfListeKommentare;
	
    /**
     * Konstruktor f&uuml;r Hibernate
     */
    public Thema(){
    	kommentare = new HashSet<Kommentar>();
    }
    
	/**
	 * Konstruktor f�r ein neuen Pinnwandbeitrag
	 * 
	 * @param inhalt Der Inhalt des Pinnwandbeitrags
	 * @param titel Der Titel des Pinnwandbeitrags
	 * @param autor Der Autor des Pinnwandbeitrags
	 */
	public Thema(String inhalt, String titel, Benutzer autor){
		this.inhalt = inhalt;
		this.titel = titel;
		this.benutzer = autor;
		bewertung = 0;
		datum = new Date();
		kommentare = new HashSet<Kommentar>();
	}
	
	/**
	 * Entfernt ein Thema und alle Relationen zu ihm
	 */
	public void entfernen(){
		pinnwand.themen.remove(this);
		benutzer = null;
		pinnwand = null;
		medium = null;
		for(Kommentar k : kommentare) {
			kommentarEntfernen(k);
		}
		kommentare.clear();
	}
	
	/**
	 * Erstellt einen Kommentar zu einem Pinnwandbeitrag (Inhalt)
	 * 
	 * @param kommentar der hinzugef&uuml;gte Kommentar
	 */
	public void kommentieren(Kommentar kommentar){
		kommentar.setThema(this);
		kommentare.add(kommentar);
	}
	
	/**
	 * L&ouml;scht einen Kommentar
	 * 
	 * @param kommentar der gel&oumlschte Kommentar
	 */
	public void kommentarEntfernen(Kommentar kommentar){
		kommentar.entfernen();
	}
	
	/**
	 * Sortiert die Kommentare nach dem neusten Datum
	 * 
	 * @return die sortierte Kommentarliste
	 */
	public boolean sortiereNachDatum(){
		Stack<Kommentar> tempStack = new Stack<Kommentar>();
		hilfListeKommentare = new ArrayList<Kommentar>();
		if (this.kommentare == null){
			return false;
		}
		for(Kommentar kommentar : this.kommentare){
			hilfListeKommentare.add(kommentar);
		}
		
		for(int i = 1; i < hilfListeKommentare.size(); i++){
			for(int j = 0; j < hilfListeKommentare.size() - 1; j++){
				if (hilfListeKommentare.get(j).getDatum().compareTo(hilfListeKommentare.get(j+1).getDatum()) > 0){
					tempStack.push(hilfListeKommentare.get(j));
					hilfListeKommentare.set(j, hilfListeKommentare.get(j+1));
					hilfListeKommentare.set(j+1, tempStack.pop());
				}
			}
		}
		return true;
	}
	
	/**
	 * Sortiert die Kommentare nach den besten Bewertungen
	 * 
	 * @return sortierte Kommentarliste
	 */
	public ArrayList<Kommentar> sortiereNachBewertung(){
		ArrayList<Kommentar> tempArrayList = new ArrayList<Kommentar>();
		
		for(Kommentar kommentar : this.kommentare){
			tempArrayList.add(kommentar);
		}
		
		Collections.sort(tempArrayList);
		return tempArrayList;
	}

    public Set<Kommentar> getKommentare(){ 
    	return kommentare;
    }
    
    public void setKommentare(Set<Kommentar> kommentare){
    	this.kommentare = kommentare;
    }
    
    public Pinnwand getPinnwand(){
    	return pinnwand;
    }
    
    public void setPinnwand(Pinnwand pinnwand){
    	this.pinnwand = pinnwand;
    }
    
    public ArrayList<Kommentar> getHilfListeKommentare() {
		return hilfListeKommentare;
	}

	public void setHilfListeKommentare(ArrayList<Kommentar> hilfListeKommentare) {
		this.hilfListeKommentare = hilfListeKommentare;
	}
}
