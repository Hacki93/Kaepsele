k�psele.de Version 1.0 23/07/2015

Herzlichen Dank f�r die Verwendung von k�psele.de!

INHALTE
----------------------------------------------------------
- Die Vorstellungspr�sentation: Pr�sentation.pdf
- Die komplilierte Software:    kaepsele.war
- Der Programmcode:             
- Die SQL-Datenbank:            db_kaepsele.sql
- Die Datenbankanleitung:       DB_Install_Anleitung.txt
- Diese README-Datei:           README.txt


GENERELLE NUTZUNGSHINWEISE
----------------------------------------------------------
- k�psele.de ben�tigt f�r den reibungslosen Betrieb eine
  installierte Java Runtime Environment 1.7 oder h�her
- k�psele.de ben�tigt f�r die reibungslose Darstellung
  Firefox 39, Chrome 42, Internet Explorer 11 oder jeweils
  h�her
  
  
INSTALLATIONSHINWEISE
----------------------------------------------------------
- Bitte beachten Sie daf�r die Datei DB_Install_Anleitung
- Die Klasse Beispieldaten f�llt die Datenbank mit Dummies
  
  
TEAM
----------------------------------------------------------
Lena Maier 			MNR: 2870610
Michael Hackenberg	MNR: 2908184
Hannes Fischer		MNR: 2862505
Christoph Jachmann  MNR: 2820042
Kevin Kruse			MNR: 2876685
  
  
KONTAKT
----------------------------------------------------------
Support: Hannes Fischer
Telefon: 0157 370 320 96
Email:   mail@hannes-fischer.com

